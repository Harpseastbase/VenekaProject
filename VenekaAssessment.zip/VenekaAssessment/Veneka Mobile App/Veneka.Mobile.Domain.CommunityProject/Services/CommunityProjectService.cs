﻿using AutoMapper;
using Veneka.Mobile.Domain.CommunityProject.ParameterModel;
using Veneka.Mobile.Infrastructure.Repository.Model;
using Veneka.Mobile.Infrastructure.Repository.Repositories.CommunityProjectRepo;

namespace Veneka.Mobile.Domain.CommunityProject.Services
{
    public class CommunityProjectService : ICommunityProjectService
    {
        private readonly ICommunityProjectRepository _communityProjectRepository;
        private readonly IMapper _mapper;

        public CommunityProjectService(IMapper mapper, ICommunityProjectRepository communityProjectRepository)
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _communityProjectRepository = communityProjectRepository ?? throw new ArgumentNullException(nameof(communityProjectRepository));
        }

        public IEnumerable<CommunityProjectModel> GetAvailableProjectList()
        {
            var communityProjectList = _communityProjectRepository.GetAvailableProjects().ToList();
           
            return _mapper.Map<IEnumerable<CommunityProjectModel>>(communityProjectList);
        }

        public bool AddCommunityProject(CommunityProjectModel communityProjectModel)
        {

            var commProj = new Veneka.Mobile.Infrastructure.Repository.Model.CommunityProject()
            {
                EndDate = communityProjectModel.EndDate,
                Name = communityProjectModel.Name,
                StartDate = communityProjectModel.StartDate,
                TotalFundsRaised = communityProjectModel.TotalFundsRaised,
                TotalFundsRequired = communityProjectModel.TotalFundsRequired,
            };

            var results = _communityProjectRepository.AddCommunityProject(commProj);
            return results;
        }
    }
}
