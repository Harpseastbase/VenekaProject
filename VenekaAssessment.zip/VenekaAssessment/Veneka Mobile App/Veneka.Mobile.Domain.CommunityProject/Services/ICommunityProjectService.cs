﻿using Veneka.Mobile.Domain.CommunityProject.ParameterModel;

namespace Veneka.Mobile.Domain.CommunityProject.Services
{
    public interface ICommunityProjectService
    {
        IEnumerable<CommunityProjectModel> GetAvailableProjectList();

        bool AddCommunityProject(CommunityProjectModel communityProject);
    }
}
