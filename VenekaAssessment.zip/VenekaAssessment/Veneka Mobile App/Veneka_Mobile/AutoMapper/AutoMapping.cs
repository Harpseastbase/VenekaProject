﻿using AutoMapper;
using Veneka.Mobile.Domain.CommunityProject.ParameterModel;
using Veneka.Mobile.Domain.Customer.ParameterModel;
using Veneka.Mobile.Domain.Payment.ParameterModel;
using Veneka.Mobile.Domain.SourceOfFunds.ParameterModel;
using Veneka.Mobile.Domain.SponsorshipPlan.ParameterModel;
using Veneka.Mobile.Infrastructure.Repository.Model;

namespace Veneka_Mobile.AutoMapper
{
    public class AutoMapping : Profile
    {
        public AutoMapping() {
            CreateMap<CommunityProject, CommunityProjectModel>();
            CreateMap<Payment, PaymentModel>();
            CreateMap<SponsorshipPlan, SponsorshipPlanModel>();
            CreateMap<Customer, CustomerModel>();
            CreateMap<SourceOfFunds, SourceOfFundsModel>();
        }
    }
}
