﻿using Carter;
using Veneka.Mobile.Domain.Payment.ParameterModel;
using Veneka.Mobile.Domain.Payment.Services;

namespace Veneka_Mobile.EndpointModules
{
    public class PaymentModule : ICarterModule
    {
        public void AddRoutes(IEndpointRouteBuilder app)
        {
            app.MapGet("Payment/GetCustomerSponsorshipPlans", (int sponsorshipPlanId, IPaymentService PaymentService) =>
            {
                try
                {
                    var customersponsorshipPlan = PaymentService.GetPaymentsForSponsorshipPlan(sponsorshipPlanId);
                    return Results.Ok(customersponsorshipPlan);
                }
                catch (Exception e)
                {
                    return Results.BadRequest(e.Message);
                }

            }).WithTags("CustomerSponsorshipPlan")
           .Produces<PaymentModel>(StatusCodes.Status200OK);

            app.MapPost("Payment/MakePayment", (int sponsorshipPlanId, decimal amount, IPaymentService PaymentService) =>
            {
                try
                {
                    var makePayment = PaymentService.MakePayment(sponsorshipPlanId, amount);
                    return Results.Ok(makePayment);
                }
                catch (Exception e)
                {
                    return Results.BadRequest(e.Message);
                }

            }).WithTags("MakePayment")
           .Produces(StatusCodes.Status200OK);
        }
    }
}
