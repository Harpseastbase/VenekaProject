﻿using Carter;
using Microsoft.AspNetCore.Mvc;
using Veneka.Mobile.Domain.CommunityProject.ParameterModel;
using Veneka.Mobile.Domain.CommunityProject.Services;
using Veneka.Mobile.Domain.SponsorshipPlan.ParameterModel;
using Veneka.Mobile.Domain.SponsorshipPlan.Services;
using Veneka.Mobile.Infrastructure.Repository.Model;

namespace Veneka_Mobile.EndpointModules
{
    public class SponsorshipPlanModule : ICarterModule
    {
        public void AddRoutes(IEndpointRouteBuilder app)
        {
            app.MapGet("SponsorshipPlan/GetAvailableProjectList", (int custmoerId, ISponsorshipPlanService sponsorshipPlanService) =>
            {
                try
                {
                    var sponsorshipPlan = sponsorshipPlanService.GetCustomerSponsorshipPlans(custmoerId);
                    return Results.Ok(sponsorshipPlan);

                }
                catch (Exception e)
                {
                    return Results.BadRequest(e.Message);
                }

            }).WithTags("SponsorshipPlanModel")
           .Produces<SponsorshipPlanModel>(StatusCodes.Status200OK);

            app.MapPost("SponsorshipPlan/CreateSponsorshipPlan", ([FromBody]  SponsorshipPlanModel sponsorshipPlanModel, ISponsorshipPlanService sponsorshipPlanService) =>
            {
                try
                {
                    var sponsorshipPlan = sponsorshipPlanService.CreateSponsorshipPlan(sponsorshipPlanModel);
                    return Results.Ok(sponsorshipPlan);

                }
                catch (Exception e)
                {
                    return Results.BadRequest(e.Message);
                }

            }).WithTags("SponsorshipPlanModel")
            .Produces<SponsorshipPlanModel>(StatusCodes.Status200OK);
        }
    }
}
