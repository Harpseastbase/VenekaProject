﻿using Carter;
using Microsoft.AspNetCore.Mvc;
using Veneka.Mobile.Domain.Customer.ParameterModel;
using Veneka.Mobile.Domain.Customer.Services;
using Veneka.Mobile.Domain.SourceOfFunds.ParameterModel;
using Veneka.Mobile.Domain.SourceOfFunds.Services;

namespace Veneka_Mobile.EndpointModules
{
    public class SourceOfFundsModule : ICarterModule
    {
        public void AddRoutes(IEndpointRouteBuilder app)
        {

            app.MapPost("SourceOfFunds/AddSourceOfFunds", ([FromBody] SourceOfFundsModel sourceOfFundsModel, ISourceOfFundsService sourceOfFundsService) =>
            {
                try
                {
                    if (sourceOfFundsModel != null)
                    {
                        var results = sourceOfFundsService.AddSourceOfFunds(sourceOfFundsModel);
                        return Results.Ok(results);
                    }
                    else
                    {
                        return Results.BadRequest("Create SourceOfFunds object cannot be null.");
                    }
                }
                catch (Exception e)
                {
                    return Results.BadRequest(e.Message);
                }

            }).WithTags("AddSourceOfFundsModel")
            .Produces(StatusCodes.Status200OK);

        }
    }
}
