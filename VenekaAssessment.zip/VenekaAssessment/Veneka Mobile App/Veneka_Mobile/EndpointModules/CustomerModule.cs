﻿using Carter;
using Microsoft.AspNetCore.Mvc;
using Veneka.Mobile.Domain.Customer.ParameterModel;
using Veneka.Mobile.Domain.Customer.Services;

namespace Veneka_Mobile.EndpointModules
{
    public class CustomerModule : ICarterModule
    {
        public void AddRoutes(IEndpointRouteBuilder app) {

            app.MapPost("Customer/AddCustomer", ([FromBody] CustomerModel customerModel, ICustomerService customerService) =>
            {
                try
                {
                    if (customerModel != null)
                    {
                        var results = customerService.AddCustomer(customerModel);
                        return Results.Ok(results);
                    }
                    else
                    {
                        return Results.BadRequest("Create customer object cannot be null.");
                    }
                }
                catch (Exception e)
                {
                    return Results.BadRequest(e.Message);
                }

            }).WithTags("AddCustomer")
            .Produces(StatusCodes.Status200OK);

        }
    }
}
