﻿using Carter;
using Microsoft.AspNetCore.Mvc;
using Veneka.Mobile.Domain.CommunityProject.ParameterModel;
using Veneka.Mobile.Domain.CommunityProject.Services;

namespace Veneka_Mobile.EndpointModules
{
    public class CommunityProjectModule : ICarterModule
    {

        public void AddRoutes(IEndpointRouteBuilder app) {

            app.MapGet("CommunityProject/GetAvailableProjectList", (ICommunityProjectService communityProjectService) =>
            {
                try {
                    
                    var commProjects = communityProjectService.GetAvailableProjectList();
                    return Results.Ok(commProjects);

                } catch (Exception e) { 
                    return Results.BadRequest(e.Message);
                }

            }).WithTags("CommunityProject")
            .Produces<CommunityProjectModel>(StatusCodes.Status200OK);

            app.MapPost("CommunityProject/AddCommunityProject",([FromBody] CommunityProjectModel communityProjectModel, ICommunityProjectService communityProjectService) =>
            {
                try
                {
                    if (communityProjectModel != null) {
                        var commProjects = communityProjectService.AddCommunityProject(communityProjectModel);
                        return Results.Ok(commProjects);
                    } 
                    else 
                    {
                        return Results.BadRequest("Create community object cannot be null.");
                    }
                }
                catch (Exception e)
                {
                    return Results.BadRequest(e.Message);
                }

            }).WithTags("CommunityProject")
            .Produces(StatusCodes.Status200OK);
        }

    }
}
