﻿using Autofac;
using Veneka.Mobile.Domain.CommunityProject.Services;
using Veneka.Mobile.Domain.Customer.Services;
using Veneka.Mobile.Domain.Payment.Services;
using Veneka.Mobile.Domain.SourceOfFunds.Services;
using Veneka.Mobile.Domain.SponsorshipPlan.Services;
using Veneka.Mobile.Infrastructure.Repository.Model;
using Veneka.Mobile.Infrastructure.Repository.Repositories.CommunityProjectRepo;
using Veneka.Mobile.Infrastructure.Repository.Repositories.CustomerRepo;
using Veneka.Mobile.Infrastructure.Repository.Repositories.PaymentRepo;
using Veneka.Mobile.Infrastructure.Repository.Repositories.SourceOfFundsRepo;
using Veneka.Mobile.Infrastructure.Repository.Repositories.SponsorshipPlanRepo;
using Veneka.Mobile.Infrastructure.Repository.Repository;

namespace Veneka_Mobile.AutoFacModules
{
    public class ApplicationModule : Autofac.Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region Repositories
                builder.RegisterType<DapperDbContext>()
                    .As<IDapperDbContext>()
                    .InstancePerLifetimeScope();
                builder.RegisterType<CommunityProjectRepository>()
                    .As<ICommunityProjectRepository>()
                    .InstancePerLifetimeScope();
                builder.RegisterType<PaymentRepository>()
                    .As<IPaymentRepository>()
                    .InstancePerLifetimeScope();
                builder.RegisterType<SponsorshipPlanRepository>()
                   .As<ISponsorshipPlanRepository>()
                   .InstancePerLifetimeScope();
                builder.RegisterType<CustomerRepository>()
                   .As<ICustomerRepository>()
                   .InstancePerLifetimeScope();
                builder.RegisterType<SourceOfFundsRepository>()
                      .As<ISourceOfFundsRepository>()
                      .InstancePerLifetimeScope();
            #endregion

            #region Services
            builder.RegisterType<CommunityProjectService>()
                    .As<ICommunityProjectService>()
                    .InstancePerLifetimeScope();
                builder.RegisterType<PaymentService>()
                    .As<IPaymentService>()
                    .InstancePerLifetimeScope();
                builder.RegisterType<SponsorshipPlanService>()
                    .As<ISponsorshipPlanService>()
                    .InstancePerLifetimeScope();
                builder.RegisterType<CustomerService>()
                     .As<ICustomerService>()
                     .InstancePerLifetimeScope();
                builder.RegisterType<SourceOfFundsService>()
                     .As<ISourceOfFundsService>()
                     .InstancePerLifetimeScope();
            #endregion
        }

    }
}
