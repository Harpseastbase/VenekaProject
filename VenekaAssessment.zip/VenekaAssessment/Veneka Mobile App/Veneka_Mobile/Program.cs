using Autofac;
using Microsoft.OpenApi.Models;
using Serilog;
using Veneka_Mobile.AutoFacModules;
using Autofac.Extensions.DependencyInjection;
using Veneka.Mobile.Infrastructure.Repository.Repository;
using System.Configuration;
using AutoMapper;
using AutoMapper.Mappers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Carter;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer.Infrastructure.Internal;
using Microsoft.EntityFrameworkCore.Infrastructure;

if (!Environment.UserInteractive)
{
    Directory.SetCurrentDirectory(AppDomain.CurrentDomain.BaseDirectory);
}

var builder = WebApplication.CreateBuilder(args);

var securityRequirement = new OpenApiSecurityRequirement()
{
    {
        new OpenApiSecurityScheme
        {
            Reference = new OpenApiReference
            {
                Type = ReferenceType.SecurityScheme,
                Id = "Bearer"
            }
        },
        new string[] {}
    }
};

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddMemoryCache();
builder.Services.AddSwaggerGen(option =>
{
    option.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Veneka Mobile API v1",
        Version = "v1",
        Description = "Veneka Mobile API v1",
    });
});

builder.Services.AddSingleton<DapperDbContext>();
builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory());

builder.Services.Configure<ConfigurationSettings>(builder.Configuration);
builder.Services.AddAutoMapper(typeof(Program));
builder.Services.AddCarter();
builder.Services.AddOptions();

builder.Host.ConfigureContainer<ContainerBuilder>(builder => builder.RegisterModule(new ApplicationModule()));
builder.Services.AddCors(options =>
{
    options.AddPolicy("Policy1", builder =>
    {
        builder.AllowAnyOrigin()
                .AllowAnyMethod()
                .SetIsOriginAllowed((host) => true)
                .AllowAnyHeader();
    });
});

builder.Host.ConfigureContainer<ContainerBuilder>((hostBuilderContext, containerBuilder) =>
{
    var configuration = hostBuilderContext.Configuration;

    containerBuilder.RegisterType<BankingDbContext>()
                    .WithParameter("options", new DbContextOptionsBuilder<BankingDbContext>()
                                                .UseSqlServer(configuration.GetConnectionString("Database"), options => {
                                                    options.EnableRetryOnFailure();
                                                })
                                                .Options)
                    .InstancePerLifetimeScope();

    containerBuilder.RegisterModule(new ApplicationModule());
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Veneka Mobile API v1");
    c.RoutePrefix = "swagger";
});

app.UseCors("Policy1");

app.MapCarter();

app.UseHttpsRedirection();

app.Run();
