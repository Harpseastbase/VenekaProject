﻿using AutoMapper;
using Veneka.Mobile.Domain.SourceOfFunds.ParameterModel;
using Veneka.Mobile.Infrastructure.Repository.Repositories.SourceOfFundsRepo;

namespace Veneka.Mobile.Domain.SourceOfFunds.Services
{
    public class SourceOfFundsService : ISourceOfFundsService
    {
        private readonly ISourceOfFundsRepository _sourceOfFundsRepository;
        private readonly IMapper _mapper;

        public SourceOfFundsService(IMapper mapper, ISourceOfFundsRepository sourceOfFundsRepository)
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _sourceOfFundsRepository = sourceOfFundsRepository ?? throw new ArgumentNullException(nameof(sourceOfFundsRepository));
        }

        public bool AddSourceOfFunds(SourceOfFundsModel sourceOfFundsModel)
        {
            var sourceOfFunds = new Veneka.Mobile.Infrastructure.Repository.Model.SourceOfFunds()
            {
                Name = sourceOfFundsModel.Name
            };

            var results = _sourceOfFundsRepository.AddSourceOfFunds(sourceOfFunds);
            return results;
        }
    }
}
