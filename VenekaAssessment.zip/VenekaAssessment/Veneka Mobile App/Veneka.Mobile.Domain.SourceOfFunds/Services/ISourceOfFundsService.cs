﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Veneka.Mobile.Domain.SourceOfFunds.ParameterModel;

namespace Veneka.Mobile.Domain.SourceOfFunds.Services
{
    public interface ISourceOfFundsService
    {
        bool AddSourceOfFunds(SourceOfFundsModel _sourceOfFunds);
    }
}
