﻿using Veneka.Mobile.Domain.SponsorshipPlan.ParameterModel;

namespace Veneka.Mobile.Domain.SourceOfFunds.ParameterModel
{
    public class SourceOfFundsModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<SponsorshipPlanModel> SponsorshipPlans { get; set; }
    }
}
