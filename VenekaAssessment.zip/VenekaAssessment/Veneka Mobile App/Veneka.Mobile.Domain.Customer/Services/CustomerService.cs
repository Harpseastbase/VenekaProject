﻿using AutoMapper;
using Veneka.Mobile.Domain.CommunityProject.ParameterModel;
using Veneka.Mobile.Domain.Customer.ParameterModel;
using Veneka.Mobile.Infrastructure.Repository.Repositories.CustomerRepo;

namespace Veneka.Mobile.Domain.Customer.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly IMapper _mapper;

        public CustomerService(IMapper mapper, ICustomerRepository customerRepository)
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _customerRepository = customerRepository ?? throw new ArgumentNullException(nameof(customerRepository));
        }

        public bool AddCustomer(CustomerModel customerModel)
        {
            var customerDetails = new Veneka.Mobile.Infrastructure.Repository.Model.Customer()
            {
                Name = customerModel.Name
            };

            var results = _customerRepository.AddCustomer(customerDetails);
            return results;
        }
    }
}
