﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Veneka.Mobile.Domain.Customer.ParameterModel;

namespace Veneka.Mobile.Domain.Customer.Services
{
    public interface ICustomerService
    {
        bool AddCustomer(CustomerModel _customer);
    }
}
