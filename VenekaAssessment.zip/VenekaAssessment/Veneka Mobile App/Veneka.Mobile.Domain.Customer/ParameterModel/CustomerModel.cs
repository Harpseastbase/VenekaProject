﻿using System.ComponentModel.DataAnnotations;
using Veneka.Mobile.Domain.SponsorshipPlan.ParameterModel;

namespace Veneka.Mobile.Domain.Customer.ParameterModel
{
    public class CustomerModel
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public List<SponsorshipPlanModel> SponsorshipPlans { get; set; }
    }
}
