﻿using System.ComponentModel.DataAnnotations;
using Veneka.Mobile.Domain.CommunityProject.ParameterModel;
using Veneka.Mobile.Domain.Customer.ParameterModel;
using Veneka.Mobile.Domain.SourceOfFunds.ParameterModel;

namespace Veneka.Mobile.Domain.SponsorshipPlan.ParameterModel
{
    public class SponsorshipPlanModel
    {
        [Key]
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public int SourceOfFundsId { get; set; }
        public string TypeOfSource { get; set; }
        public int CommunityProjectId { get; set; }
        public string PaymentFrequency { get; set; }
        public decimal AmountPerPayment { get; set; }
        public CustomerModel Customer { get; set; }
        public SourceOfFundsModel SourceOfFunds { get; set; }
        public CommunityProjectModel CommunityProject { get; set; }
    }
}
