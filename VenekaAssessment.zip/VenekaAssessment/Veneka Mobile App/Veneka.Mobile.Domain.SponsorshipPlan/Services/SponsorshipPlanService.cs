﻿using AutoMapper;
using Veneka.Mobile.Domain.SponsorshipPlan.ParameterModel;
using Veneka.Mobile.Infrastructure.Repository.Repositories.SponsorshipPlanRepo;

namespace Veneka.Mobile.Domain.SponsorshipPlan.Services
{
    public class SponsorshipPlanService : ISponsorshipPlanService
    {
        private readonly ISponsorshipPlanRepository _sponsorshipPlanRepository;
        private readonly IMapper _mapper;

        public SponsorshipPlanService(IMapper mapper, ISponsorshipPlanRepository sponsorshipPlanRepository)
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _sponsorshipPlanRepository = sponsorshipPlanRepository ?? throw new ArgumentNullException(nameof(sponsorshipPlanRepository));
        }

        public IEnumerable<SponsorshipPlanModel> GetCustomerSponsorshipPlans(int customerId) {
            var sponsorshipPlansList = _sponsorshipPlanRepository.GetCustomerSponsorshipPlans(customerId).ToList();

            return _mapper.Map<IEnumerable<SponsorshipPlanModel>>(sponsorshipPlansList);
        }

        public bool CreateSponsorshipPlan(SponsorshipPlanModel _sponsorshipPlan) {

            var sponsPlan = new Veneka.Mobile.Infrastructure.Repository.Model.SponsorshipPlan()
            {
                AmountPerPayment = _sponsorshipPlan.AmountPerPayment,
                CustomerId = _sponsorshipPlan.CustomerId,
                PaymentFrequency = _sponsorshipPlan.PaymentFrequency,
                SourceOfFundsId = _sponsorshipPlan.SourceOfFundsId,
                TypeOfSource = _sponsorshipPlan.TypeOfSource,
                CommunityProjectId = _sponsorshipPlan.CommunityProjectId,

            };

            var results = _sponsorshipPlanRepository.CreateSponsorshipPlan(sponsPlan);
            return results;
        }
    }
}
