﻿using Veneka.Mobile.Domain.SponsorshipPlan.ParameterModel;

namespace Veneka.Mobile.Domain.SponsorshipPlan.Services
{
    public interface ISponsorshipPlanService
    {
        IEnumerable<SponsorshipPlanModel> GetCustomerSponsorshipPlans(int customerId);

        bool CreateSponsorshipPlan(SponsorshipPlanModel _sponsorshipPlan);
    }
}
