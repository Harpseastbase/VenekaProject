﻿using AutoMapper;
using Veneka.Mobile.Domain.Payment.ParameterModel;
using Veneka.Mobile.Domain.SponsorshipPlan.ParameterModel;
using Veneka.Mobile.Infrastructure.Repository.Model;
using Veneka.Mobile.Infrastructure.Repository.Repositories.PaymentRepo;
using Veneka.Mobile.Infrastructure.Repository.Repositories.SponsorshipPlanRepo;

namespace Veneka.Mobile.Domain.Payment.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly IPaymentRepository _paymentRepository;
        private readonly IMapper _mapper;

        public PaymentService(IMapper mapper, IPaymentRepository paymentRepository)
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _paymentRepository = paymentRepository ?? throw new ArgumentNullException(nameof(paymentRepository));
        }
        public IEnumerable<PaymentModel> GetPaymentsForSponsorshipPlan(int sponsorshipPlanId) {

            var paymentsSponsorshipList = _paymentRepository.GetPaymentsForSponsorshipPlan(sponsorshipPlanId).ToList();

            return _mapper.Map<IEnumerable<PaymentModel>>(paymentsSponsorshipList);
        }
        
        public bool MakePayment(int sponsorshipPlanId, decimal amount) {
            var makePayment = _paymentRepository.MakePayment(sponsorshipPlanId, amount);
            return makePayment;
        }
    }
}
