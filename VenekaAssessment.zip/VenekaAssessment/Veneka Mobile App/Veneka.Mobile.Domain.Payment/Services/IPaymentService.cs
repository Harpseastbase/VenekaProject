﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Veneka.Mobile.Domain.Payment.ParameterModel;

namespace Veneka.Mobile.Domain.Payment.Services
{
    public interface IPaymentService
    {
        IEnumerable<PaymentModel> GetPaymentsForSponsorshipPlan(int sponsorshipPlanId);
        bool MakePayment(int sponsorshipPlanId, decimal amount);
    }
}
