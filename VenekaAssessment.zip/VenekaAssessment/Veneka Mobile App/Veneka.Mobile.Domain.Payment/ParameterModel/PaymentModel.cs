﻿using System.ComponentModel.DataAnnotations;
using Veneka.Mobile.Domain.SponsorshipPlan.ParameterModel;

namespace Veneka.Mobile.Domain.Payment.ParameterModel
{
    public class PaymentModel
    {
        public int Id { get; set; }
        public int SponsorshipPlanId { get; set; }
        public DateTime PaymentDate { get; set; }
        public decimal Amount { get; set; }
        public SponsorshipPlanModel SponsorshipPlan { get; set; }
    }
}
