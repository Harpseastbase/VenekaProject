﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using System.Reflection;
using Veneka.Mobile.Infrastructure.Repository.Repository;
using static Veneka.Mobile.Infrastructure.Repository.Core.IRepository;

namespace Veneka.Mobile.Infrastructure.Repository.Core
{
    public class Repository<T> : IRepository<T>
        where T : class
    {
        public readonly BankingDbContext _dbContext;

        public DbSet<T> dbSet;

        public Repository(BankingDbContext dbContext)
        {
            _dbContext = dbContext;
            dbSet = dbContext.Set<T>();
        }
        public async Task BulkDelete(IEnumerable<T> entities)
        {
            _dbContext.Set<T>().RemoveRange(entities);
            await _dbContext.SaveChangesAsync();
        }

        public async Task BulkInsert(IEnumerable<T> entities)
        {
            _dbContext.Set<T>().AddRange(entities);
            await _dbContext.SaveChangesAsync();
        }
        public async Task BulkUpdate(IEnumerable<T> entities)
        {
            _dbContext.Set<T>().UpdateRange(entities);
            await _dbContext.SaveChangesAsync();
        }

        public async Task<T> Create(T entity)
        {
            await _dbContext.Set<T>().AddAsync(entity);
            await _dbContext.SaveChangesAsync();
            return entity;
        }

        public void DisableTracking(IEnumerable<T> entities)
        {
            foreach (var entry in entities)
                _dbContext.Entry(entry).State = EntityState.Detached;
        }

        public bool Exists(Expression<Func<T, bool>> predicate)
        {
            return _dbContext.Set<T>().AsNoTracking().AsQueryable().Any(predicate);
        }

        public IEnumerable<T> Find(Expression<Func<T, bool>> predicate)
        {
            return _dbContext.Set<T>().AsNoTracking().AsQueryable().Where(predicate);
        }

        public T First(Expression<Func<T, bool>> predicate)
        {
            return _dbContext.Set<T>().AsNoTracking().AsQueryable().First(predicate);
        }

        public async Task<T> FirstOrDefault(Expression<Func<T, bool>> predicate)
        {
            var result = await _dbContext.Set<T>().AsNoTracking().FirstOrDefaultAsync(predicate);

            return result!;
        }

        public async Task Update(T entity)
        {
            dbSet.Attach(entity);
            _dbContext.Entry(entity).State = EntityState.Modified;

            var entry = _dbContext.Entry(entity);

            Type type = typeof(T);
            PropertyInfo[] properties = type.GetProperties();

            properties.AsParallel().ForAll(x =>
            {
                if (x.GetValue(entity, null) == null)
                {
                    entry.Property(x.Name).IsModified = false;
                }
            });

            await _dbContext.SaveChangesAsync();
        }
    }
}
