﻿using System.Linq.Expressions;

namespace Veneka.Mobile.Infrastructure.Repository.Core
{
    public interface IRepository
    {
        public interface IRepository<T> where T : class
        {
            T First(Expression<Func<T, bool>> predicate);

            Task<T> FirstOrDefault(Expression<Func<T, bool>> predicate);

            IEnumerable<T> Find(Expression<Func<T, bool>> predicate);

            Task<T> Create(T entity);

            Task Update(T entity);

            Task BulkUpdate(IEnumerable<T> entities);

            Task BulkDelete(IEnumerable<T> entities);

            Task BulkInsert(IEnumerable<T> entities);

            void DisableTracking(IEnumerable<T> entities);

            bool Exists(Expression<Func<T, bool>> predicate);
        }
    }
}
