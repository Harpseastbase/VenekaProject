﻿using System.Data;
using Veneka.Mobile.Infrastructure.Repository.Repository;
using Dapper;

namespace Veneka.Mobile.Infrastructure.Repository.Core
{
    public class DapperRepository<T> : IDapperRepository<T>
         where T : class
    {
        public readonly IDapperDbContext _dapperDbContext;

        public DapperRepository(IDapperDbContext dapperDbContext)
        {
            _dapperDbContext = dapperDbContext;
        }
        public async Task<int> ExecuteAsync(string sql, object? param = null, IDbTransaction? transaction = null, CancellationToken cancellationToken = default)
        {
            return await _dapperDbContext.CreateConnection().ExecuteAsync(sql, param, transaction);
        }

        public object ExecuteScalar(string sql, object? param = null, IDbTransaction? transaction = null, CommandType commandType = CommandType.Text, CancellationToken cancellationToken = default)
        {
            return _dapperDbContext.CreateConnection().ExecuteScalar(sql, param, transaction, commandType: commandType);
        }

        public IEnumerable<T> Query(string sql, object? param = null, IDbTransaction? transaction = null, CommandType commandType = CommandType.Text, CancellationToken cancellationToken = default)
        {
            return _dapperDbContext.CreateConnection().Query<T>(sql, param, transaction, commandType: commandType).AsEnumerable();
        }

        public async Task<IEnumerable<T>> QueryAsync(string sql, object? param = null, IDbTransaction? transaction = null, CommandType commandType = CommandType.Text, CancellationToken cancellationToken = default)
        {
            return await _dapperDbContext.CreateConnection().QueryAsync<T>(sql, param, transaction);
        }

        public async Task<T> QueryFirstOrDefaultAsync(string sql, object? param = null, IDbTransaction? transaction = null, CancellationToken cancellationToken = default)
        {
            return await _dapperDbContext.CreateConnection().QueryFirstOrDefaultAsync<T>(sql, param, transaction);
        }

        public async Task<T> QuerySingleOrDefaultAsync(string sql, object? param = null, IDbTransaction? transaction = null, CancellationToken cancellationToken = default)
        {
            return await _dapperDbContext.CreateConnection().QuerySingleOrDefaultAsync<T>(sql, param, transaction);
        }
    }
}
