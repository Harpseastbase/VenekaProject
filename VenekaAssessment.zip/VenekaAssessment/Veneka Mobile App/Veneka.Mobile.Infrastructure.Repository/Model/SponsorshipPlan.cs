﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veneka.Mobile.Infrastructure.Repository.Model
{
    public class SponsorshipPlan
    {
        [Key]
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public int SourceOfFundsId { get; set; }
        public string TypeOfSource { get; set; }
        public int CommunityProjectId { get; set; }
        public string PaymentFrequency { get; set; }
        public decimal AmountPerPayment { get; set; }
        public Customer Customer { get; set; }
        public SourceOfFunds SourceOfFunds { get; set; }
        public CommunityProject CommunityProject { get; set; }
    }
}
