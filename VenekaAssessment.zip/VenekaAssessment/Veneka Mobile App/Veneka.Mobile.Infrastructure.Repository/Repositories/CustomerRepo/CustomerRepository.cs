﻿using Veneka.Mobile.Infrastructure.Repository.Core;
using Veneka.Mobile.Infrastructure.Repository.Model;
using Veneka.Mobile.Infrastructure.Repository.Repository;

namespace Veneka.Mobile.Infrastructure.Repository.Repositories.CustomerRepo
{
    public class CustomerRepository : Repository<Customer>, ICustomerRepository
    {
        public CustomerRepository(BankingDbContext dbContext) : base(dbContext)
        {

        }

        public bool AddCustomer(Customer _customer) {
            _dbContext.Customers.Add(_customer);
            _dbContext.SaveChanges();
            return true;
        }
    }
}
