﻿using Veneka.Mobile.Infrastructure.Repository.Model;
using static Veneka.Mobile.Infrastructure.Repository.Core.IRepository;

namespace Veneka.Mobile.Infrastructure.Repository.Repositories.CustomerRepo
{
    public interface ICustomerRepository : IRepository<Customer>
    {
        bool AddCustomer(Customer _customer);
    }
}
