﻿using Microsoft.EntityFrameworkCore;
using static Dapper.SqlMapper;
using System.Data;
using System.Linq.Expressions;
using Veneka.Mobile.Infrastructure.Repository.Model;
using Veneka.Mobile.Infrastructure.Repository.Core;
using Veneka.Mobile.Infrastructure.Repository.Repository;

namespace Veneka.Mobile.Infrastructure.Repository.Repositories.CommunityProjectRepo
{
    public class CommunityProjectRepository : Repository<CommunityProject>, ICommunityProjectRepository
    {
        public CommunityProjectRepository(BankingDbContext dbContext) : base(dbContext)
        {
        }

        public IEnumerable<CommunityProject> GetAvailableProjects()
        {
            return _dbContext.CommunityProjects.AsEnumerable();
        }

        public bool AddCommunityProject(CommunityProject _communityProject)
        {
            _dbContext.CommunityProjects.Add(_communityProject);
            _dbContext.SaveChanges();
            return true;
        }
    }
}
