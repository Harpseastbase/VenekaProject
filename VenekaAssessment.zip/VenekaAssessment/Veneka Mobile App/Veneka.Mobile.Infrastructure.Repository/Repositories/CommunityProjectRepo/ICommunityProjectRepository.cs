﻿using Veneka.Mobile.Infrastructure.Repository.Model;
using static Veneka.Mobile.Infrastructure.Repository.Core.IRepository;

namespace Veneka.Mobile.Infrastructure.Repository.Repositories.CommunityProjectRepo
{
    public interface ICommunityProjectRepository : IRepository<CommunityProject>
    {
        IEnumerable<CommunityProject> GetAvailableProjects();

        bool AddCommunityProject(CommunityProject _communityProject);
    }
}
