﻿using Veneka.Mobile.Infrastructure.Repository.Model;
using static Veneka.Mobile.Infrastructure.Repository.Core.IRepository;

namespace Veneka.Mobile.Infrastructure.Repository.Repositories.SponsorshipPlanRepo
{
    public interface ISponsorshipPlanRepository : IRepository<SponsorshipPlan>
    {
        IEnumerable<SponsorshipPlan> GetCustomerSponsorshipPlans(int customerId);

        bool CreateSponsorshipPlan(SponsorshipPlan _sponsorshipPlan);
    }
}
