﻿using Veneka.Mobile.Infrastructure.Repository.Core;
using Veneka.Mobile.Infrastructure.Repository.Model;
using Veneka.Mobile.Infrastructure.Repository.Repository;

namespace Veneka.Mobile.Infrastructure.Repository.Repositories.SponsorshipPlanRepo
{
    public class SponsorshipPlanRepository : Repository<SponsorshipPlan>, ISponsorshipPlanRepository
    {
        public SponsorshipPlanRepository(BankingDbContext dbContext) : base(dbContext)
        {
        }

        public bool CreateSponsorshipPlan(SponsorshipPlan _sponsorshipPlan) {
            _dbContext.SponsorshipPlans.Add(_sponsorshipPlan);
            _dbContext.SaveChanges();
            return true;
        }

        public IEnumerable<SponsorshipPlan> GetCustomerSponsorshipPlans(int customerId)
        {
            return _dbContext.SponsorshipPlans.Where(plan => plan.CustomerId == customerId).ToList();
        }
    }
}
