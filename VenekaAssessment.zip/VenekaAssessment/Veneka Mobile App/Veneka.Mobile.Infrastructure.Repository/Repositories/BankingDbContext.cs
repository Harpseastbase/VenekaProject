﻿using Microsoft.EntityFrameworkCore;
using Veneka.Mobile.Infrastructure.Repository.Model;

namespace Veneka.Mobile.Infrastructure.Repository.Repository
{
    public class BankingDbContext : DbContext
    {
        public BankingDbContext(DbContextOptions<BankingDbContext> options) : base(options)
        {
        }

        public DbSet<CommunityProject> CommunityProjects { get; set; }
        public DbSet<SponsorshipPlan> SponsorshipPlans { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<SourceOfFunds> SourceOfFunds { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CommunityProject>().HasKey(cp => cp.Id);
            modelBuilder.Entity<SponsorshipPlan>().HasKey(sp => sp.Id);
            modelBuilder.Entity<Customer>().HasKey(c => c.Id);
            modelBuilder.Entity<Payment>().HasKey(p => p.Id);
            modelBuilder.Entity<SourceOfFunds>().HasKey(sf => sf.Id);

            modelBuilder.Entity<Customer>()
             .HasMany(c => c.SponsorshipPlans)
              .WithOne(sp => sp.Customer)
              .HasForeignKey(sp => sp.CustomerId);

            modelBuilder.Entity<SourceOfFunds>()
            .HasMany(sf => sf.SponsorshipPlans)
            .WithOne(sp => sp.SourceOfFunds) 
            .HasForeignKey(sp => sp.SourceOfFundsId);

        }
    }
}
