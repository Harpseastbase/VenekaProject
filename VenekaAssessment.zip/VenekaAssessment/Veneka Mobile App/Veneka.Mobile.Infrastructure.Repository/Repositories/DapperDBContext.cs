﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veneka.Mobile.Infrastructure.Repository.Repository
{
    public class DapperDbContext : IDapperDbContext
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public DapperDbContext(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetSection("ConnectionString").Value ?? "";
        }

        public IDbConnection CreateConnection()
        => new SqlConnection(_connectionString);
    }
}
