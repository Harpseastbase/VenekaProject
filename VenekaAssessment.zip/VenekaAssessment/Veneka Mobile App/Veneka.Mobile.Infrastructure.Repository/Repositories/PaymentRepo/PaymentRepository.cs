﻿using Veneka.Mobile.Infrastructure.Repository.Core;
using Veneka.Mobile.Infrastructure.Repository.Model;
using Veneka.Mobile.Infrastructure.Repository.Repository;

namespace Veneka.Mobile.Infrastructure.Repository.Repositories.PaymentRepo
{
    public class PaymentRepository :  Repository<Payment>,IPaymentRepository
    {
        public PaymentRepository(BankingDbContext dbContext) : base(dbContext) { 


        }

        public IEnumerable<Payment> GetPaymentsForSponsorshipPlan(int sponsorshipPlanId) {
            return _dbContext.Payments.Where(payment => payment.SponsorshipPlanId == sponsorshipPlanId).ToList();
        }

        public bool MakePayment(int sponsorshipPlanId, decimal amount) {

            var payment = new Payment
            {
                SponsorshipPlanId = sponsorshipPlanId,
                PaymentDate = DateTime.Now,
                Amount = amount
            };

            _dbContext.Payments.Add(payment);
            _dbContext.SaveChanges();
            return true;

        }
    }
}
