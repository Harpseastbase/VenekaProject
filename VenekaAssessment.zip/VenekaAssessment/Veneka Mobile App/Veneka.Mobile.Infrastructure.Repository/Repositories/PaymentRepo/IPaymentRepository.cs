﻿using Veneka.Mobile.Infrastructure.Repository.Model;
using static Veneka.Mobile.Infrastructure.Repository.Core.IRepository;

namespace Veneka.Mobile.Infrastructure.Repository.Repositories.PaymentRepo
{
    public interface IPaymentRepository : IRepository<Payment>
    {
        IEnumerable<Payment> GetPaymentsForSponsorshipPlan(int sponsorshipPlanId);
        bool MakePayment(int sponsorshipPlanId, decimal amount);
    }
}
