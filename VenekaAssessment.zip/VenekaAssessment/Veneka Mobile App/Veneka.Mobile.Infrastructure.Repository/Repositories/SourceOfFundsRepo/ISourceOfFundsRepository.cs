﻿using Veneka.Mobile.Infrastructure.Repository.Core;
using Veneka.Mobile.Infrastructure.Repository.Model;
using static Veneka.Mobile.Infrastructure.Repository.Core.IRepository;

namespace Veneka.Mobile.Infrastructure.Repository.Repositories.SourceOfFundsRepo
{
    public interface ISourceOfFundsRepository : IRepository<SourceOfFunds>
    {
        bool AddSourceOfFunds(SourceOfFunds _sourceOfFunds);
    }
}
