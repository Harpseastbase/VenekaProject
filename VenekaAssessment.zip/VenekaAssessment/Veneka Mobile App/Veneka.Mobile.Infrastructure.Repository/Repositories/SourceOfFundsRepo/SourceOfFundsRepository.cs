﻿using Veneka.Mobile.Infrastructure.Repository.Core;
using Veneka.Mobile.Infrastructure.Repository.Model;
using Veneka.Mobile.Infrastructure.Repository.Repository;

namespace Veneka.Mobile.Infrastructure.Repository.Repositories.SourceOfFundsRepo
{
    public class SourceOfFundsRepository : Repository<SourceOfFunds>, ISourceOfFundsRepository
    {
        public SourceOfFundsRepository(BankingDbContext dbContext) : base(dbContext)
        {

        }

        public bool AddSourceOfFunds(SourceOfFunds _sourceOfFunds)
        {
            _dbContext.SourceOfFunds.Add(_sourceOfFunds);
            _dbContext.SaveChanges();
            return true;
        }
    }
}
